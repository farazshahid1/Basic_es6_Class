import PlaceInfo from './PlaceInfo'

let placeInfo = new PlaceInfo('japan')

placeInfo.geolocation();

setTimeout(()=>{ 

        console.log("done")
        placeInfo.find()
    
    }, 6000);



setTimeout(()=>{ 

     placeInfo.PlaceInfodisplay(); 

}, 10000);
