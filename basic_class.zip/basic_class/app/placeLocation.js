import {geocode} from '../functions/geoLocation'

class PlaceLocation {

    constructor(name){
        this._info = {

             latitude: 0,
             longitude: 0
        };

        this._name= name;
       
    }
 
    get latitude(){
        return this._info.latitude
    }

    get longitude(){
        return this._info.longitude
    }

    set name(newName){
        this._name=newName
    }

    set info(info){

        const {latitude, longitude} = info
        this._info={
            latitude,
            longitude
        }
    }

    display() {
        console.log(`Name of Place is ${this._name}`)
        console.log(`Latitude is ${this._info.latitude}`)
        console.log(`longitude is ${this._info.longitude}`)

    }

    async geolocation() {
        const {latitude, longitude, location, } = await geocode(this._name);
        this._name=location;
        this._info={latitude, longitude};
      
    }

}

export default PlaceLocation