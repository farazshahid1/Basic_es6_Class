import {forecast} from '../functions/geoLocation'
import PlaceLocation from './placeLocation'

class PlaceInfo extends PlaceLocation {
    constructor(name) {
      super(name);
      this._temperature = 0,
      this._summary = ""

    }

    PlaceInfodisplay() {
        this.display()
      console.log(`It is ${this._summary}`)
      console.log(`It is Currently ${this._temperature} temperature in ${this._name}`)
    

  }

  async find() {
     
      const {summary, temperature } = await forecast(this._info.latitude, this._info.longitude);
      this._temperature=temperature;
      this._summary=summary;
  }
}

export default PlaceInfo