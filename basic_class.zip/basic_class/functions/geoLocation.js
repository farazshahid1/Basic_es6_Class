import fetch from "cross-fetch"

export const geocode = async (address) => {

    const url = 'https://api.mapbox.com/geocoding/v5/mapbox.places/'+ encodeURIComponent(address) +'.json?access_token=pk.eyJ1IjoiZmFyYXpzaGFoaWQxIiwiYSI6ImNrN3lvOThpeDAwY2szZ3FxamppMTY5bXMifQ.9W-8GrvP4WnJNYRSnvSSBw'

    try {
        
        const res = await fetch(url);

        if(res.status >= 400 ) {
            throw new Error("Bad response from server");
        }
        const user = await res.json();
        
        
        const info = {
            latitude: user.features[0].center[1],
            longitude: user.features[0].center[0],
            location: user.features[0].place_name
        }
      //  console.log(info);
      return info;
    } catch (err) {
        console.log("Error")
        console.log(err);
    }

}


export const forecast = async (latitude, longitude) => {
    const url = 'https://cors-anywhere.herokuapp.com/https://api.darksky.net/forecast/195ca987ca37b2ade73084bb2b53559c/'+ latitude  +',' + longitude +'?units=si'

   try{
        const res = await fetch(url)

        if(res.status >= 400) {
            throw new Error("Bad response from Server");
        }
        const body = await res.json();

        if(body.error){
            throw new Error("Unable to find location");
        }

         //console.log(body.timezone)
        // console.log(body.currently.temperature)
        const info = {
            summary: body.currently.summary,
            temperature: body.currently.temperature
        }
      //  console.log(info);
      return info;

   }catch(e) {

    console.log("Error in forecast")
    console.log(e);
   }
}



